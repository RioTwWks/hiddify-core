package hcommon

type AppSettings struct {
	Id    string
	Value any
}
